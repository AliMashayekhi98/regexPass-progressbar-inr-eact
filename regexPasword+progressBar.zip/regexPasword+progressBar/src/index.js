import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import 'bootstrap/dist/css/bootstrap.min.css';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  < >
  <div style={{
  width:'2200px',
  height:'1000px',
  textAlign:'center',
  backgroundImage:`url(./wall.jpg)`}}> 
  <App/>
  
  </div>
  </>
);

